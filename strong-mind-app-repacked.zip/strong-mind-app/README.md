# Strong Mind — PWA starter

A functional, dependency-free, installable 30-day personal development and nutrition tracking web app.

## Run

Use a local HTTP server: `python3 -m http.server 8000` then open http://localhost:8000. Deploy the folder as a static site on Render or GitHub Pages with HTTPS. On iPhone Safari, use Share → Add to Home Screen.

## Current features

- 30 days of learning themes, publisher links, Calm links, practical actions, journals, four independent sign-offs per day.
- Start date, calendar navigation, daily completion, persistence using localStorage.
- Food diary with manually entered per-100-g nutrient data and gram portion scaling; 26 nutrients including vitamins and minerals.
- Customizable daily targets, progress tracking, JSON backup export.
- Offline shell and saved programme content via service worker.

## Important limitations

- Publisher catalogue links are not guaranteed direct episode links; verify individual episodes before production.
- No food database integration or barcode scanner yet; micronutrients must be entered manually from reliable labels/data. Missing nutrient values remain unknown. A daily total may be partial if some foods lack data.
- Local-only storage does not sync across devices; no push reminders yet.
- No automatic import from Spotify, Calm, Apple Health or Cronometer.
- Nutrition goals are illustrative and not medical advice.

## Codex next task

1. Add a Node.js backend with secure authentication and per-user persistent database (PostgreSQL on Render). Implement migration from localStorage, data export and deletion.
2. Add USDA FoodData Central server-side API proxy (API key in environment variables) with food search and nutrient unit normalization. Add Australian packaged-food data where licensing permits. Store source provenance, missing nutrients and nutrient measurement basis; avoid interpreting missing as zero.
3. Add barcode lookup with Open Food Facts and source attribution; user verification before logging. Support saved meals and recipes.
4. Add local notifications with explicit user opt-in and time zone-aware scheduling; implement a missed-day catch-up policy.
5. Verify and replace all 30 catalogue links with specific working episode links and precise listening start points. Never invent episode URLs.
6. Add CSV export, tests (nutrient scaling, day boundaries, sign-off persistence), mobile accessibility and install QA.
7. Audit security, privacy and backup/recovery before production.
